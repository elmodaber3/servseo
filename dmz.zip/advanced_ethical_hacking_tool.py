#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║           🔒 ADVANCED ETHICAL HACKING & PENETRATION TESTING TOOL 🔒           ║
║                    أداة متقدمة لاختبار الاختراق الأخلاقي                       ║
║                         للاستخدام الأخلاقي والتعليمي فقط                       ║
╚═══════════════════════════════════════════════════════════════════════════════╝

⚠️  WARNING / تحذير ⚠️
هذه الأداة مخصصة للاستخدام الأخلاقي والتعليمي فقط!
لا تستخدم هذه الأداة على أي موقع إلا إذا كنت:
1- صاحب الموقع، أو
2- لديك إذن كتابي صريح من صاحب الموقع

الاستخدام غير القانوني قد يعرضك للمساءلة القانونية!
"""

import socket
import requests
import ssl
import json
import time
import sys
import re
import threading
import hashlib
from urllib.parse import urljoin, urlparse, parse_qs, quote
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import warnings
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

# الألوان للعرض
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

class AdvancedEthicalHackingTool:
    def __init__(self, target):
        self.target = target
        self.results = {
            "target": target,
            "scan_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "open_ports": [],
            "services": {},
            "vulnerabilities": [],
            "server_info": {},
            "headers": {},
            "technologies": [],
            "dns_info": {},
            "ssl_info": {},
            "directories": [],
            "sql_injection_tests": [],
            "xss_tests": [],
            "csrf_tests": [],
            "open_redirect_tests": [],
            "clickjacking_tests": [],
            "file_exposure": [],
            "api_endpoints": [],
            "subdomains": [],
            "cookies_analysis": [],
            "security_misconfigurations": []
        }
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        self.base_url = None

    def print_banner(self):
        banner = f"""
{Colors.OKCYAN}
╔═══════════════════════════════════════════════════════════════════════════════╗
║           🔒 ADVANCED ETHICAL HACKING & PENETRATION TESTING TOOL 🔒           ║
║                    أداة متقدمة لاختبار الاختراق الأخلاقي                       ║
╚═══════════════════════════════════════════════════════════════════════════════╝
{Colors.ENDC}
{Colors.WARNING}⚠️  تحذير: استخدم هذه الأداة فقط على مواقع تملكها أو لديك إذن باختبارها ⚠️{Colors.ENDC}

{Colors.OKGREEN}[+] الهدف: {self.target}{Colors.ENDC}
{Colors.OKGREEN}[+] تاريخ الفحص: {self.results["scan_date"]}{Colors.ENDC}
"""
        print(banner)

    # ═══════════════════════════════════════════════════════════════
    # 1. فحص المنافذ المتقدم
    # ═══════════════════════════════════════════════════════════════
    def scan_port(self, port):
        """فحص منفذ واحد مع تحديد الخدمة"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex((self.target, port))
            if result == 0:
                try:
                    service = socket.getservbyport(port)
                except:
                    service = "unknown"

                # محاولة الحصول على لافتة (Banner)
                banner = ""
                try:
                    sock.settimeout(1)
                    if port in [80, 443, 8080, 8443]:
                        sock.send(b"HEAD / HTTP/1.0\r\n\r\n")
                    else:
                        sock.send(b"\r\n")
                    banner = sock.recv(1024).decode('utf-8', errors='ignore').strip()
                except:
                    pass

                self.results["open_ports"].append({
                    "port": port,
                    "service": service,
                    "state": "open",
                    "banner": banner[:200] if banner else ""
                })

                banner_str = f" - Banner: {banner[:50]}..." if banner else ""
                print(f"{Colors.OKGREEN}[+] المنفذ المفتوح: {port}/tcp - {service}{banner_str}{Colors.ENDC}")
            sock.close()
        except Exception as e:
            pass

    def port_scan(self, start_port=1, end_port=1000, common_only=False):
        """فحص المنافذ الشامل"""
        if common_only:
            common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389, 5432, 5900, 8080, 8443]
            print(f"\n{Colors.HEADER}[*] بدء فحص المنافذ الشائعة...{Colors.ENDC}\n")
            ports = common_ports
        else:
            print(f"\n{Colors.HEADER}[*] بدء فحص المنافذ من {start_port} إلى {end_port}...{Colors.ENDC}\n")
            ports = range(start_port, end_port + 1)

        with ThreadPoolExecutor(max_workers=150) as executor:
            futures = [executor.submit(self.scan_port, port) for port in ports]
            for future in as_completed(futures):
                pass

        print(f"\n{Colors.OKGREEN}[✓] تم اكتشاف {len(self.results['open_ports'])} منفذ مفتوح{Colors.ENDC}\n")

    # ═══════════════════════════════════════════════════════════════
    # 2. جمع المعلومات المتقدم
    # ═══════════════════════════════════════════════════════════════
    def get_dns_info(self):
        """جمع معلومات DNS المتقدمة"""
        print(f"{Colors.HEADER}[*] جمع معلومات DNS...{Colors.ENDC}")
        try:
            # IP Address
            ip = socket.gethostbyname(self.target)
            self.results["dns_info"]["ip"] = ip
            print(f"{Colors.OKGREEN}[+] عنوان IP: {ip}{Colors.ENDC}")

            # Reverse DNS
            try:
                reverse_dns = socket.gethostbyaddr(ip)
                self.results["dns_info"]["reverse_dns"] = reverse_dns[0]
                print(f"{Colors.OKGREEN}[+] Reverse DNS: {reverse_dns[0]}{Colors.ENDC}")
            except:
                pass

            # MX Records (محاكاة)
            print(f"{Colors.OKCYAN}[*] البحث عن سجلات MX...{Colors.ENDC}")

        except Exception as e:
            print(f"{Colors.FAIL}[-] خطأ في جمع معلومات DNS: {e}{Colors.ENDC}")

    def enumerate_subdomains(self):
        """استكشاف النطاقات الفرعية"""
        print(f"\n{Colors.HEADER}[*] استكشاف النطاقات الفرعية...{Colors.ENDC}")

        common_subdomains = [
            'www', 'mail', 'ftp', 'localhost', 'webmail', 'smtp', 'pop', 'ns1', 'webdisk',
            'ns2', 'cpanel', 'whm', 'autodiscover', 'autoconfig', 'ns3', 'm', 'imap',
            'test', 'ns', 'blog', 'pop3', 'dev', 'www2', 'admin', 'forum', 'news',
            'vpn', 'ns4', 'www1', 'imap4', 'home', 'direct', 'mail2', 'support',
            'mobile', 'remote', 'webdisk2', 'admin2', 'secure', 'demo', 'api', 'beta'
        ]

        found_subdomains = []

        for sub in common_subdomains:
            subdomain = f"{sub}.{self.target}"
            try:
                ip = socket.gethostbyname(subdomain)
                if ip:
                    found_subdomains.append({"subdomain": subdomain, "ip": ip})
                    print(f"{Colors.OKGREEN}[+] نطاق فرعي: {subdomain} -> {ip}{Colors.ENDC}")
            except:
                pass

        self.results["subdomains"] = found_subdomains
        print(f"{Colors.OKGREEN}[✓] تم اكتشاف {len(found_subdomains)} نطاق فرعي{Colors.ENDC}")

    # ═══════════════════════════════════════════════════════════════
    # 3. فحص الموقع الشامل
    # ═══════════════════════════════════════════════════════════════
    def get_server_info(self, url):
        """جمع معلومات السيرفر المتقدمة"""
        print(f"\n{Colors.HEADER}[*] جمع معلومات السيرفر...{Colors.ENDC}")
        try:
            response = self.session.get(url, timeout=15, verify=False, allow_redirects=True)
            headers = response.headers
            self.results["headers"] = dict(headers)

            # Server
            server = headers.get('Server', 'Unknown')
            self.results["server_info"]["server"] = server
            print(f"{Colors.OKGREEN}[+] نوع السيرفر: {server}{Colors.ENDC}")

            # Powered By
            powered_by = headers.get('X-Powered-By', 'Unknown')
            self.results["server_info"]["powered_by"] = powered_by
            if powered_by != 'Unknown':
                print(f"{Colors.OKGREEN}[+] تقنية السيرفر: {powered_by}{Colors.ENDC}")

            # Content-Type
            content_type = headers.get('Content-Type', 'Unknown')
            print(f"{Colors.OKGREEN}[+] نوع المحتوى: {content_type}{Colors.ENDC}")

            # Cookies Analysis
            self.analyze_cookies(response)

            # Detect Technologies
            self.detect_technologies(headers, response.text)

            # Check for WAF
            self.detect_waf(headers)

        except Exception as e:
            print(f"{Colors.FAIL}[-] خطأ: {e}{Colors.ENDC}")

    def analyze_cookies(self, response):
        """تحليل الكوكيز"""
        print(f"\n{Colors.HEADER}[*] تحليل الكوكيز...{Colors.ENDC}")

        cookies = response.cookies
        for cookie in cookies:
            cookie_info = {
                "name": cookie.name,
                "secure": cookie.secure,
                "httponly": cookie.has_nonstandard_attr('HttpOnly'),
                "samesite": cookie.has_nonstandard_attr('SameSite')
            }

            issues = []
            if not cookie.secure:
                issues.append("لا يستخدم Secure flag")
            if not cookie.has_nonstandard_attr('HttpOnly'):
                issues.append("لا يستخدم HttpOnly flag")
            if not cookie.has_nonstandard_attr('SameSite'):
                issues.append("لا يستخدم SameSite attribute")

            if issues:
                print(f"{Colors.WARNING}[!] الكوكيز {cookie.name}: {', '.join(issues)}{Colors.ENDC}")
                self.results["cookies_analysis"].append({
                    "cookie": cookie.name,
                    "issues": issues,
                    "severity": "Medium"
                })
            else:
                print(f"{Colors.OKGREEN}[✓] الكوكيز {cookie.name}: آمن{Colors.ENDC}")

    def detect_waf(self, headers):
        """الكشف عن جدار الحماية WAF"""
        print(f"\n{Colors.HEADER}[*] الكشف عن WAF...{Colors.ENDC}")

        waf_signatures = {
            'Cloudflare': ['cf-ray', 'cloudflare', '__cfduid'],
            'AWS WAF': ['awselb', 'x-amzn-requestid'],
            'Incapsula': ['incap_ses', 'visid_incap'],
            'ModSecurity': ['mod_security'],
            'Sucuri': ['sucuri', 'x-sucuri'],
            'Akamai': ['akamai'],
            'F5 BIG-IP': ['bigip', 'f5'],
            'Barracuda': ['barra'],
            'Citrix': ['citrix'],
            'Imperva': ['incap_ses']
        }

        detected_wafs = []
        headers_str = str(headers).lower()

        for waf, signatures in waf_signatures.items():
            for sig in signatures:
                if sig.lower() in headers_str:
                    detected_wafs.append(waf)
                    print(f"{Colors.OKGREEN}[+] WAF مكتشف: {waf}{Colors.ENDC}")
                    break

        if not detected_wafs:
            print(f"{Colors.WARNING}[!] لم يتم اكتشاف WAF واضح{Colors.ENDC}")

        self.results["server_info"]["waf"] = detected_wafs

    def detect_technologies(self, headers, content):
        """الكشف عن التقنيات المستخدمة"""
        print(f"\n{Colors.HEADER}[*] الكشف عن التقنيات المستخدمة...{Colors.ENDC}")

        technologies = []

        tech_signatures = {
            'WordPress': ['wp-content', 'wp-includes', '/wp-json/', 'wordpress'],
            'Drupal': ['drupal', 'Drupal', 'sites/default'],
            'Joomla': ['joomla', 'Joomla', '/media/jui/'],
            'Magento': ['magento', 'Mage.Cookies'],
            'Shopify': ['shopify', 'myshopify'],
            'React': ['react', 'reactjs', 'react-root'],
            'Angular': ['angular', 'ng-', 'ng-app'],
            'Vue.js': ['vue', 'vue.js', '__VUE__'],
            'Next.js': ['__NEXT_DATA__', '_next/'],
            'jQuery': ['jquery', 'jQuery'],
            'Bootstrap': ['bootstrap', 'bootstrap.min.css'],
            'Laravel': ['laravel', 'laravel_session'],
            'Django': ['django', 'csrftoken'],
            'Flask': ['flask'],
            'Ruby on Rails': ['rails', 'csrf-token'],
            'Express.js': ['express'],
            'Spring': ['spring', 'X-Application-Context'],
            'PHP': ['PHP', '.php'],
            'ASP.NET': ['ASP.NET', 'X-AspNet-Version', '__VIEWSTATE'],
            'Nginx': ['nginx'],
            'Apache': ['apache', 'Apache', 'mod_'],
            'IIS': ['IIS', 'Microsoft-IIS'],
            'Tomcat': ['tomcat', 'Apache-Coyote'],
            'CloudFlare': ['cloudflare', 'cf-ray'],
            'AWS': ['aws', 'amazonaws', 'x-amz'],
            'Google Cloud': ['google cloud', 'gcp'],
            'Azure': ['azure', 'windows-azure'],
            'Fastly': ['fastly'],
            'CDN77': ['cdn77'],
            'MaxCDN': ['maxcdn']
        }

        for tech, signatures in tech_signatures.items():
            for signature in signatures:
                if signature in str(headers) or signature in content:
                    if tech not in technologies:
                        technologies.append(tech)
                        print(f"{Colors.OKGREEN}[+] تم اكتشاف: {tech}{Colors.ENDC}")
                        break

        self.results["technologies"] = technologies

    # ═══════════════════════════════════════════════════════════════
    # 4. فحص SSL/TLS المتقدم
    # ═══════════════════════════════════════════════════════════════
    def check_ssl(self):
        """فحص SSL/TLS المتقدم"""
        print(f"\n{Colors.HEADER}[*] فحص SSL/TLS...{Colors.ENDC}")
        try:
            context = ssl.create_default_context()
            with socket.create_connection((self.target, 443), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=self.target) as ssock:
                    cert = ssock.getpeercert()
                    cipher = ssock.cipher()
                    version = ssock.version()

                    self.results["ssl_info"] = {
                        "version": version,
                        "cipher": cipher[0],
                        "issuer": cert.get('issuer'),
                        "subject": cert.get('subject'),
                        "not_after": cert.get('notAfter'),
                        "not_before": cert.get('notBefore'),
                        "serial_number": cert.get('serialNumber'),
                        "subject_alt_name": cert.get('subjectAltName')
                    }

                    print(f"{Colors.OKGREEN}[+] إصدار SSL/TLS: {version}{Colors.ENDC}")
                    print(f"{Colors.OKGREEN}[+] التشفير المستخدم: {cipher[0]}{Colors.ENDC}")
                    print(f"{Colors.OKGREEN}[+] الجهة المصدرة: {cert.get('issuer')}{Colors.ENDC}")
                    print(f"{Colors.OKGREEN}[+] صالح حتى: {cert.get('notAfter')}{Colors.ENDC}")

                    # Check for weak protocols
                    weak_protocols = ['SSLv2', 'SSLv3', 'TLSv1.0', 'TLSv1.1']
                    if version in weak_protocols:
                        print(f"{Colors.FAIL}[!] تحذير: يستخدم بروتوكول ضعيف: {version}{Colors.ENDC}")
                        self.results["vulnerabilities"].append({
                            "type": "Weak SSL/TLS Protocol",
                            "protocol": version,
                            "description": f"يستخدم بروتوكول {version} الضعيف",
                            "severity": "High"
                        })

        except Exception as e:
            print(f"{Colors.FAIL}[-] خطأ في فحص SSL: {e}{Colors.ENDC}")

    # ═══════════════════════════════════════════════════════════════
    # 5. فحص الملفات الحساسة
    # ═══════════════════════════════════════════════════════════════
    def check_sensitive_files(self, url):
        """فحص الملفات والمجلدات الحساسة"""
        print(f"\n{Colors.HEADER}[*] فحص الملفات والمجلدات الحساسة...{Colors.ENDC}")

        sensitive_paths = [
            '/admin/', '/administrator/', '/admin/login', '/admin/login.php',
            '/wp-admin/', '/wp-login.php', '/wp-config.php',
            '/phpmyadmin/', '/pma/', '/myadmin/',
            '/config/', '/configuration/', '/.env',
            '/backup/', '/backups/', '/bak/',
            '/test/', '/testing/', '/dev/', '/development/',
            '/api/', '/api/v1/', '/swagger/', '/api-docs/',
            '/.git/', '/.svn/', '/.hg/',
            '/robots.txt', '/sitemap.xml', '/crossdomain.xml',
            '/phpinfo.php', '/info.php', '/server-status',
            '/.htaccess', '/.htpasswd', '/web.config',
            '/error_log', '/access_log', '/debug.log',
            '/install/', '/setup/', '/installer/',
            '/uploads/', '/upload/', '/files/',
            '/xmlrpc.php', '/wp-json/wp/v2/users/',
            '/.DS_Store', '/Thumbs.db',
            '/database.sql', '/backup.sql', '/dump.sql',
            '/.docker/', '/docker-compose.yml', '/Dockerfile',
            '/.github/', '/.gitlab-ci.yml',
            '/composer.json', '/package.json',
            '/readme.md', '/README.md', '/CHANGELOG.md',
            '/license.txt', '/LICENSE.txt'
        ]

        found_files = []

        for path in sensitive_paths:
            try:
                test_url = urljoin(url, path)
                response = self.session.get(test_url, timeout=5, verify=False, allow_redirects=False)

                if response.status_code == 200:
                    size = len(response.content)
                    print(f"{Colors.FAIL}[!!!] ملف/مجلد مكشوف: {path} ({size} bytes){Colors.ENDC}")
                    found_files.append({
                        "path": path,
                        "url": test_url,
                        "status": response.status_code,
                        "size": size
                    })

                    self.results["vulnerabilities"].append({
                        "type": "Sensitive File/Directory Exposure",
                        "path": path,
                        "url": test_url,
                        "severity": "High" if 'admin' in path or 'config' in path or '.env' in path else "Medium"
                    })
                elif response.status_code in [301, 302, 307]:
                    print(f"{Colors.WARNING}[!] إعادة توجيه: {path} -> {response.headers.get('Location', 'Unknown')}{Colors.ENDC}")

            except Exception as e:
                pass

        self.results["file_exposure"] = found_files
        print(f"\n{Colors.OKGREEN}[✓] تم فحص {len(sensitive_paths)} مسار، {len(found_files)} مكشوف{Colors.ENDC}")

    def check_robots_txt(self, url):
        """فحص ملف robots.txt"""
        print(f"\n{Colors.HEADER}[*] فحص robots.txt...{Colors.ENDC}")
        try:
            robots_url = urljoin(url, '/robots.txt')
            response = self.session.get(robots_url, timeout=5, verify=False)

            if response.status_code == 200:
                print(f"{Colors.OKGREEN}[+] robots.txt موجود{Colors.ENDC}")
                lines = response.text.split('\n')
                disallowed = [line for line in lines if line.startswith('Disallow')]

                if disallowed:
                    print(f"{Colors.OKCYAN}[*] المسارات المحظورة:{Colors.ENDC}")
                    for line in disallowed[:10]:
                        print(f"    {line}")

                    # Check for sensitive paths in robots.txt
                    sensitive_keywords = ['admin', 'login', 'config', 'api', 'private', 'secret', 'backup']
                    for line in disallowed:
                        for keyword in sensitive_keywords:
                            if keyword in line.lower():
                                print(f"{Colors.WARNING}[!] مسار حساس مذكور في robots.txt: {line}{Colors.ENDC}")
                                break
            else:
                print(f"{Colors.WARNING}[!] robots.txt غير موجود{Colors.ENDC}")

        except Exception as e:
            print(f"{Colors.FAIL}[-] خطأ: {e}{Colors.ENDC}")

    # ═══════════════════════════════════════════════════════════════
    # 6. فحص رؤوس الأمان
    # ═══════════════════════════════════════════════════════════════
    def check_security_headers(self, url):
        """فحص رؤوس الأمان"""
        print(f"\n{Colors.HEADER}[*] فحص رؤوس الأمان...{Colors.ENDC}")

        try:
            response = self.session.get(url, timeout=10, verify=False)
            headers = response.headers

            security_headers = {
                'Strict-Transport-Security': {
                    'description': 'HSTS - يفرض استخدام HTTPS',
                    'severity': 'High'
                },
                'Content-Security-Policy': {
                    'description': 'CSP - يمنع هجمات XSS و Injection',
                    'severity': 'High'
                },
                'X-Frame-Options': {
                    'description': 'يمنع هجمات Clickjacking',
                    'severity': 'Medium'
                },
                'X-Content-Type-Options': {
                    'description': 'يمنع MIME-sniffing',
                    'severity': 'Medium'
                },
                'X-XSS-Protection': {
                    'description': 'حماية XSS إضافية',
                    'severity': 'Low'
                },
                'Referrer-Policy': {
                    'description': 'يتحكم في معلومات المرجع',
                    'severity': 'Low'
                },
                'Permissions-Policy': {
                    'description': 'يتحكم في ميزات المتصفح',
                    'severity': 'Low'
                }
            }

            missing_headers = []

            for header, info in security_headers.items():
                if header in headers:
                    value = headers[header]
                    print(f"{Colors.OKGREEN}[✓] {header}: {value[:50]}{Colors.ENDC}")
                else:
                    missing_headers.append(header)
                    severity_color = Colors.FAIL if info['severity'] == 'High' else Colors.WARNING if info['severity'] == 'Medium' else Colors.OKCYAN
                    print(f"{severity_color}[✗] {header}: مفقود - {info['description']}{Colors.ENDC}")

                    self.results["vulnerabilities"].append({
                        "type": "Missing Security Header",
                        "header": header,
                        "description": info['description'],
                        "severity": info['severity']
                    })

            return missing_headers

        except Exception as e:
            print(f"{Colors.FAIL}[-] خطأ: {e}{Colors.ENDC}")
            return []

    # ═══════════════════════════════════════════════════════════════
    # 7. فحص Clickjacking
    # ═══════════════════════════════════════════════════════════════
    def test_clickjacking(self, url):
        """اختبار Clickjacking"""
        print(f"\n{Colors.HEADER}[*] اختبار Clickjacking...{Colors.ENDC}")

        try:
            response = self.session.get(url, timeout=10, verify=False)
            headers = response.headers

            x_frame_options = headers.get('X-Frame-Options', '').upper()
            csp = headers.get('Content-Security-Policy', '')

            if x_frame_options in ['DENY', 'SAMEORIGIN']:
                print(f"{Colors.OKGREEN}[✓] محمي ضد Clickjacking (X-Frame-Options: {x_frame_options}){Colors.ENDC}")
            elif 'frame-ancestors' in csp:
                print(f"{Colors.OKGREEN}[✓] محمي ضد Clickjacking (CSP frame-ancestors){Colors.ENDC}")
            else:
                print(f"{Colors.FAIL}[!!!] عرضة لهجوم Clickjacking!{Colors.ENDC}")
                self.results["vulnerabilities"].append({
                    "type": "Clickjacking",
                    "description": "الموقع يمكن عرضه في iframe (X-Frame-Options مفقود)",
                    "severity": "Medium"
                })

        except Exception as e:
            print(f"{Colors.FAIL}[-] خطأ: {e}{Colors.ENDC}")

    # ═══════════════════════════════════════════════════════════════
    # 8. فحص Open Redirect
    # ═══════════════════════════════════════════════════════════════
    def test_open_redirect(self, url):
        """اختبار Open Redirect"""
        print(f"\n{Colors.HEADER}[*] اختبار Open Redirect...{Colors.ENDC}")

        redirect_payloads = [
            'https://evil.com',
            '//evil.com',
            'http://evil.com',
            '/\evil.com',
            'https:evil.com',
            'javascript:alert(1)'
        ]

        parsed = urlparse(url)
        common_params = ['url', 'redirect', 'return', 'returnUrl', 'returnTo', 'next', 'goto', 'redir', 'r']

        found_vulnerabilities = []

        for param in common_params:
            for payload in redirect_payloads:
                try:
                    test_url = f"{parsed.scheme}://{parsed.netloc}/?{param}={quote(payload)}"
                    response = self.session.get(test_url, timeout=5, verify=False, allow_redirects=False)

                    if response.status_code in [301, 302, 307]:
                        location = response.headers.get('Location', '')
                        if 'evil.com' in location or payload in location:
                            print(f"{Colors.FAIL}[!!!] Open Redirect مكتشف! المعامل: {param}{Colors.ENDC}")
                            print(f"{Colors.FAIL}    الحمولة: {payload}{Colors.ENDC}")
                            found_vulnerabilities.append({
                                "parameter": param,
                                "payload": payload
                            })
                            break

                except Exception as e:
                    pass

        if found_vulnerabilities:
            self.results["vulnerabilities"].append({
                "type": "Open Redirect",
                "description": "إعادة توجيه مفتوحة مكتشفة",
                "details": found_vulnerabilities,
                "severity": "Medium"
            })
        else:
            print(f"{Colors.OKGREEN}[✓] لم يتم اكتشاف Open Redirect واضح{Colors.ENDC}")

    # ═══════════════════════════════════════════════════════════════
    # 9. فحص SQL Injection
    # ═══════════════════════════════════════════════════════════════
    def test_sql_injection(self, url):
        """اختبار SQL Injection المتقدم"""
        print(f"\n{Colors.HEADER}[*] اختبار SQL Injection...{Colors.ENDC}")

        sql_payloads = [
            "'",
            "''",
            "' OR '1'='1",
            "' OR '1'='1' --",
            "' OR '1'='1' /*",
            "' OR 1=1",
            "' OR 1=1 --",
            "' OR 1=1 /*",
            "1' ORDER BY 1--+",
            "1' ORDER BY 2--+",
            "1' ORDER BY 3--+",
            "1' UNION SELECT NULL--+",
            "1' UNION SELECT NULL,NULL--+",
            "1' AND 1=1--+",
            "1' AND 1=2--+",
            "' AND SLEEP(5)--",
            "' AND (SELECT * FROM (SELECT(SLEEP(5)))a)--",
            "1 AND 1=1",
            "1 AND 1=2",
            "1 AND 1=1--",
            "1 AND 1=2--"
        ]

        error_signatures = [
            "sql syntax",
            "mysql_fetch",
            "pg_query",
            "sqlite_query",
            "ORA-",
            "SQL Server",
            "ODBC",
            "mysqli",
            "PDOException",
            "PostgreSQL",
            "Warning: mysql",
            "You have an error in your SQL syntax"
        ]

        parsed = urlparse(url)
        if parsed.query:
            params = parse_qs(parsed.query)

            for param in params:
                for payload in sql_payloads:
                    try:
                        test_params = params.copy()
                        test_params[param] = payload
                        test_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}?"
                        test_url += "&".join([f"{k}={quote(v[0])}" for k, v in test_params.items()])

                        start_time = time.time()
                        response = self.session.get(test_url, timeout=10, verify=False)
                        elapsed_time = time.time() - start_time

                        # Check for SQL errors
                        for error in error_signatures:
                            if error.lower() in response.text.lower():
                                vuln = {
                                    "type": "SQL Injection",
                                    "parameter": param,
                                    "payload": payload,
                                    "url": test_url,
                                    "evidence": error,
                                    "severity": "Critical"
                                }
                                self.results["sql_injection_tests"].append(vuln)
                                self.results["vulnerabilities"].append(vuln)
                                print(f"{Colors.FAIL}[!!!] تم اكتشاف SQL Injection في المعامل: {param}{Colors.ENDC}")
                                print(f"{Colors.FAIL}    الحمولة: {payload}{Colors.ENDC}")
                                print(f"{Colors.FAIL}    الدليل: {error}{Colors.ENDC}")
                                return

                        # Check for time-based SQLi
                        if elapsed_time > 4 and 'SLEEP' in payload:
                            vuln = {
                                "type": "Time-Based SQL Injection",
                                "parameter": param,
                                "payload": payload,
                                "url": test_url,
                                "response_time": elapsed_time,
                                "severity": "Critical"
                            }
                            self.results["sql_injection_tests"].append(vuln)
                            self.results["vulnerabilities"].append(vuln)
                            print(f"{Colors.FAIL}[!!!] تم اكتشاف Time-Based SQL Injection في المعامل: {param}{Colors.ENDC}")
                            print(f"{Colors.FAIL}    الحمولة: {payload}{Colors.ENDC}")
                            print(f"{Colors.FAIL}    وقت الاستجابة: {elapsed_time:.2f} ثانية{Colors.ENDC}")
                            return

                    except Exception as e:
                        pass

        print(f"{Colors.OKGREEN}[✓] لم يتم اكتشاف SQL Injection واضح{Colors.ENDC}")

    # ═══════════════════════════════════════════════════════════════
    # 10. فحص XSS
    # ═══════════════════════════════════════════════════════════════
    def test_xss(self, url):
        """اختبار XSS المتقدم"""
        print(f"\n{Colors.HEADER}[*] اختبار Cross-Site Scripting (XSS)...{Colors.ENDC}")

        xss_payloads = [
            "<script>alert('XSS')</script>",
            "<img src=x onerror=alert('XSS')>",
            "<svg onload=alert('XSS')>",
            "javascript:alert('XSS')",
            "<body onload=alert('XSS')>",
            "<iframe src=javascript:alert('XSS')>",
            "<scr<script>ipt>alert('XSS')</scr</script>ipt>",
            "<img src="javascript:alert('XSS')">",
            "<a href="javascript:alert('XSS')">click</a>",
            "<input onfocus=alert('XSS') autofocus>",
            "<select onfocus=alert('XSS') autofocus>",
            "<textarea onfocus=alert('XSS') autofocus>",
            "<keygen onfocus=alert('XSS') autofocus>",
            "<video><source onerror="alert('XSS')">",
            "<audio src=x onerror=alert('XSS')>",
            "<marquee onstart=alert('XSS')>",
            "<meter onmouseover=alert('XSS')>",
            "<details ontoggle=alert('XSS')>",
            "<object data=javascript:alert('XSS')>",
            "<embed src=javascript:alert('XSS')>"
        ]

        parsed = urlparse(url)
        if parsed.query:
            params = parse_qs(parsed.query)

            for param in params:
                for payload in xss_payloads:
                    try:
                        test_params = params.copy()
                        test_params[param] = payload
                        test_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}?"
                        test_url += "&".join([f"{k}={quote(v[0])}" for k, v in test_params.items()])

                        response = self.session.get(test_url, timeout=10, verify=False)

                        if payload in response.text:
                            vuln = {
                                "type": "Cross-Site Scripting (XSS)",
                                "parameter": param,
                                "payload": payload,
                                "url": test_url,
                                "severity": "High"
                            }
                            self.results["xss_tests"].append(vuln)
                            self.results["vulnerabilities"].append(vuln)
                            print(f"{Colors.FAIL}[!!!] تم اكتشاف XSS في المعامل: {param}{Colors.ENDC}")
                            print(f"{Colors.FAIL}    الحمولة: {payload}{Colors.ENDC}")
                            return

                    except Exception as e:
                        pass

        print(f"{Colors.OKGREEN}[✓] لم يتم اكتشاف XSS واضح{Colors.ENDC}")

    # ═══════════════════════════════════════════════════════════════
    # 11. فحص شامل
    # ═══════════════════════════════════════════════════════════════
    def full_scan(self, url):
        """فحص شامل للموقع"""
        self.base_url = url

        print(f"\n{Colors.BOLD}{Colors.OKCYAN}╔═══════════════════════════════════════════════════════════════╗{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}║                    بدء الفحص الشامل                          ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}╚═══════════════════════════════════════════════════════════════╝{Colors.ENDC}\n")

        # 1. DNS Info
        self.get_dns_info()

        # 2. Subdomain Enumeration
        self.enumerate_subdomains()

        # 3. Port Scan (Common Ports)
        self.port_scan(common_only=True)

        # 4. Server Info
        self.get_server_info(url)

        # 5. SSL Check
        self.check_ssl()

        # 6. Sensitive Files
        self.check_sensitive_files(url)

        # 7. robots.txt
        self.check_robots_txt(url)

        # 8. Security Headers
        self.check_security_headers(url)

        # 9. Clickjacking
        self.test_clickjacking(url)

        # 10. Open Redirect
        self.test_open_redirect(url)

        # 11. SQL Injection Test
        self.test_sql_injection(url)

        # 12. XSS Test
        self.test_xss(url)

        print(f"\n{Colors.BOLD}{Colors.OKGREEN}╔═══════════════════════════════════════════════════════════════╗{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKGREEN}║                    تم الانتهاء من الفحص الشامل               ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKGREEN}╚═══════════════════════════════════════════════════════════════╝{Colors.ENDC}\n")

    # ═══════════════════════════════════════════════════════════════
    # 12. إنشاء التقرير
    # ═══════════════════════════════════════════════════════════════
    def generate_report(self, filename=None):
        """إنشاء تقرير شامل"""
        if filename is None:
            filename = f"pentest_report_{self.target.replace('.', '_')}_{int(time.time())}.json"

        # حساب إحصائيات
        critical = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "Critical"])
        high = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "High"])
        medium = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "Medium"])
        low = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "Low"])

        self.results["summary"] = {
            "total_vulnerabilities": len(self.results["vulnerabilities"]),
            "critical": critical,
            "high": high,
            "medium": medium,
            "low": low,
            "open_ports": len(self.results["open_ports"]),
            "subdomains_found": len(self.results["subdomains"]),
            "technologies_found": len(self.results["technologies"]),
            "sensitive_files": len(self.results["file_exposure"]),
            "sql_injection_tests": len(self.results["sql_injection_tests"]),
            "xss_tests": len(self.results["xss_tests"])
        }

        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=4, ensure_ascii=False)

        print(f"{Colors.OKGREEN}[✓] تم حفظ التقرير في: {filename}{Colors.ENDC}")

        # طباعة ملخص
        print(f"\n{Colors.BOLD}{Colors.HEADER}╔═══════════════════════════════════════════════════════════════╗{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}║                      ملخص النتائج                            ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}╠═══════════════════════════════════════════════════════════════╣{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}║  إجمالي الثغرات: {len(self.results['vulnerabilities'])}                                          ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.FAIL}║  خطيرة (Critical): {critical}                                        ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.WARNING}║  عالية (High): {high}                                              ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}║  متوسطة (Medium): {medium}                                         ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKGREEN}║  منخفضة (Low): {low}                                               ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}╠═══════════════════════════════════════════════════════════════╣{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}║  المنافذ المفتوحة: {len(self.results['open_ports'])}                                         ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}║  النطاقات الفرعية: {len(self.results['subdomains'])}                                         ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}║  التقنيات المكتشفة: {len(self.results['technologies'])}                                        ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}║  الملفات الحساسة: {len(self.results['file_exposure'])}                                         ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}╚═══════════════════════════════════════════════════════════════╝{Colors.ENDC}\n")

        return filename

    def generate_html_report(self, filename=None):
        """إنشاء تقرير HTML جميل"""
        if filename is None:
            filename = f"pentest_report_{self.target.replace('.', '_')}_{int(time.time())}.html"

        critical = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "Critical"])
        high = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "High"])
        medium = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "Medium"])
        low = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "Low"])

        html_content = f"""
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقرير اختبار الاختراق - {self.target}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            line-height: 1.6;
            min-height: 100vh;
        }}

        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }}

        .header {{
            text-align: center;
            padding: 40px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }}

        .header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}

        .header p {{
            font-size: 1.2em;
            opacity: 0.9;
        }}

        .warning {{
            background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }}

        .summary-cards {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}

        .card {{
            background: rgba(255,255,255,0.1);
            padding: 25px;
            border-radius: 15px;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
            transition: transform 0.3s;
        }}

        .card:hover {{
            transform: translateY(-5px);
        }}

        .card.critical {{
            border-color: #ff416c;
            background: rgba(255,65,108,0.2);
        }}

        .card.high {{
            border-color: #ff9f43;
            background: rgba(255,159,67,0.2);
        }}

        .card.medium {{
            border-color: #54a0ff;
            background: rgba(84,160,255,0.2);
        }}

        .card.low {{
            border-color: #1dd1a1;
            background: rgba(29,209,161,0.2);
        }}

        .card h3 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}

        .card p {{
            font-size: 1.1em;
            opacity: 0.9;
        }}

        .section {{
            background: rgba(255,255,255,0.05);
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 20px;
            border: 1px solid rgba(255,255,255,0.1);
        }}

        .section h2 {{
            color: #667eea;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }}

        .vulnerability {{
            background: rgba(255,255,255,0.05);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
            border-right: 4px solid;
        }}

        .vulnerability.critical {{
            border-color: #ff416c;
            background: rgba(255,65,108,0.1);
        }}

        .vulnerability.high {{
            border-color: #ff9f43;
            background: rgba(255,159,67,0.1);
        }}

        .vulnerability.medium {{
            border-color: #54a0ff;
            background: rgba(84,160,255,0.1);
        }}

        .vulnerability.low {{
            border-color: #1dd1a1;
            background: rgba(29,209,161,0.1);
        }}

        .vulnerability h4 {{
            margin-bottom: 10px;
            font-size: 1.2em;
        }}

        .badge {{
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: bold;
            margin-left: 10px;
        }}

        .badge.critical {{
            background: #ff416c;
        }}

        .badge.high {{
            background: #ff9f43;
        }}

        .badge.medium {{
            background: #54a0ff;
        }}

        .badge.low {{
            background: #1dd1a1;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }}

        th, td {{
            padding: 12px;
            text-align: right;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }}

        th {{
            background: rgba(102,126,234,0.3);
            font-weight: bold;
        }}

        tr:hover {{
            background: rgba(255,255,255,0.05);
        }}

        .footer {{
            text-align: center;
            padding: 30px;
            margin-top: 30px;
            opacity: 0.7;
        }}

        @media (max-width: 768px) {{
            .header h1 {{
                font-size: 1.8em;
            }}

            .summary-cards {{
                grid-template-columns: 1fr;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔒 تقرير اختبار الاختراق</h1>
            <p>{self.target} | {self.results["scan_date"]}</p>
        </div>

        <div class="warning">
            <strong>⚠️ تحذير:</strong> هذا التقرير مخصص للاستخدام الأخلاقي والتعليمي فقط!
        </div>

        <div class="summary-cards">
            <div class="card critical">
                <h3>{critical}</h3>
                <p>خطيرة (Critical)</p>
            </div>
            <div class="card high">
                <h3>{high}</h3>
                <p>عالية (High)</p>
            </div>
            <div class="card medium">
                <h3>{medium}</h3>
                <p>متوسطة (Medium)</p>
            </div>
            <div class="card low">
                <h3>{low}</h3>
                <p>منخفضة (Low)</p>
            </div>
        </div>
"""

        # إضافة الثغرات
        if self.results["vulnerabilities"]:
            html_content += """
        <div class="section">
            <h2>🐛 الثغرات المكتشفة</h2>
"""
            for vuln in self.results["vulnerabilities"]:
                severity = vuln.get("severity", "Low").lower()
                html_content += f"""
            <div class="vulnerability {severity}">
                <h4>{vuln['type']} <span class="badge {severity}">{vuln.get('severity', 'Low')}</span></h4>
                <p><strong>الوصف:</strong> {vuln.get('description', 'لا يوجد وصف')}</p>
                {f'<p><strong>المعامل:</strong> {vuln["parameter"]}</p>' if 'parameter' in vuln else ''}
                {f'<p><strong>الحمولة:</strong> <code>{vuln["payload"]}</code></p>' if 'payload' in vuln else ''}
                {f'<p><strong>الدليل:</strong> {vuln.get("evidence", "")}</p>' if 'evidence' in vuln else ''}
            </div>
"""
            html_content += "        </div>"

        # إضافة المنافذ المفتوحة
        if self.results["open_ports"]:
            html_content += """
        <div class="section">
            <h2>🔌 المنافذ المفتوحة</h2>
            <table>
                <tr>
                    <th>المنفذ</th>
                    <th>الخدمة</th>
                    <th>الحالة</th>
                </tr>
"""
            for port in self.results["open_ports"]:
                html_content += f"""
                <tr>
                    <td>{port['port']}</td>
                    <td>{port['service']}</td>
                    <td>{port['state']}</td>
                </tr>
"""
            html_content += "            </table>        </div>"

        # إضافة معلومات السيرفر
        if self.results["server_info"]:
            html_content += """
        <div class="section">
            <h2>🖥️ معلومات السيرفر</h2>
            <table>
"""
            for key, value in self.results["server_info"].items():
                if key != 'waf':
                    html_content += f"""
                <tr>
                    <td><strong>{key}</strong></td>
                    <td>{value}</td>
                </tr>
"""
            html_content += "            </table>        </div>"

        # إضافة التقنيات
        if self.results["technologies"]:
            html_content += """
        <div class="section">
            <h2>⚙️ التقنيات المكتشفة</h2>
            <div style="display: flex; flex-wrap: wrap; gap: 10px;">
"""
            for tech in self.results["technologies"]:
                html_content += f'<span style="background: rgba(102,126,234,0.3); padding: 8px 15px; border-radius: 20px;">{tech}</span>'
            html_content += "            </div>        </div>"

        # إضافة SSL Info
        if self.results["ssl_info"]:
            html_content += """
        <div class="section">
            <h2>🔐 معلومات SSL/TLS</h2>
            <table>
"""
            for key, value in self.results["ssl_info"].items():
                html_content += f"""
                <tr>
                    <td><strong>{key}</strong></td>
                    <td>{value}</td>
                </tr>
"""
            html_content += "            </table>        </div>"

        # Footer
        html_content += """
        <div class="footer">
            <p>تم إنشاء هذا التقرير بواسطة Advanced Ethical Hacking Tool</p>
            <p>للاستخدام الأخلاقي والتعليمي فقط</p>
        </div>
    </div>
</body>
</html>
"""

        with open(filename, 'w', encoding='utf-8') as f:
            f.write(html_content)

        print(f"{Colors.OKGREEN}[✓] تم حفظ التقرير HTML في: {filename}{Colors.ENDC}")
        return filename

    def print_detailed_report(self):
        """طباعة تقرير مفصل"""
        print(f"\n{Colors.BOLD}{Colors.OKCYAN}═══════════════════════════════════════════════════════════════{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}                    التقرير التفصيلي                          {Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}═══════════════════════════════════════════════════════════════{Colors.ENDC}\n")

        # المنافذ المفتوحة
        if self.results["open_ports"]:
            print(f"{Colors.HEADER}[+] المنافذ المفتوحة:{Colors.ENDC}")
            for port in self.results["open_ports"]:
                banner_str = f" - {port['banner'][:50]}..." if port.get('banner') else ""
                print(f"    {Colors.OKGREEN}- المنفذ {port['port']}/tcp: {port['service']}{banner_str}{Colors.ENDC}")

        # النطاقات الفرعية
        if self.results["subdomains"]:
            print(f"\n{Colors.HEADER}[+] النطاقات الفرعية:{Colors.ENDC}")
            for sub in self.results["subdomains"]:
                print(f"    {Colors.OKGREEN}- {sub['subdomain']} -> {sub['ip']}{Colors.ENDC}")

        # معلومات السيرفر
        if self.results["server_info"]:
            print(f"\n{Colors.HEADER}[+] معلومات السيرفر:{Colors.ENDC}")
            for key, value in self.results["server_info"].items():
                if key != 'waf':
                    print(f"    {Colors.OKGREEN}- {key}: {value}{Colors.ENDC}")

        # التقنيات
        if self.results["technologies"]:
            print(f"\n{Colors.HEADER}[+] التقنيات المكتشفة:{Colors.ENDC}")
            for tech in self.results["technologies"]:
                print(f"    {Colors.OKGREEN}- {tech}{Colors.ENDC}")

        # الملفات المكشوفة
        if self.results["file_exposure"]:
            print(f"\n{Colors.HEADER}[+] الملفات/المجلدات المكشوفة:{Colors.ENDC}")
            for file in self.results["file_exposure"]:
                print(f"    {Colors.FAIL}- {file['path']} ({file['size']} bytes){Colors.ENDC}")

        # الثغرات
        if self.results["vulnerabilities"]:
            print(f"\n{Colors.HEADER}[+] الثغرات المكتشفة:{Colors.ENDC}")
            for i, vuln in enumerate(self.results["vulnerabilities"], 1):
                severity_color = Colors.OKGREEN
                if vuln.get("severity") == "Critical":
                    severity_color = Colors.FAIL
                elif vuln.get("severity") == "High":
                    severity_color = Colors.WARNING
                elif vuln.get("severity") == "Medium":
                    severity_color = Colors.OKCYAN

                print(f"\n    {Colors.BOLD}{severity_color}[{i}] {vuln['type']}{Colors.ENDC}")
                print(f"    {Colors.OKCYAN}الخطورة: {vuln.get('severity', 'Unknown')}{Colors.ENDC}")
                if 'parameter' in vuln:
                    print(f"    {Colors.OKCYAN}المعامل: {vuln['parameter']}{Colors.ENDC}")
                if 'description' in vuln:
                    print(f"    {Colors.OKCYAN}الوصف: {vuln['description']}{Colors.ENDC}")
                if 'payload' in vuln:
                    print(f"    {Colors.OKCYAN}الحمولة: {vuln['payload']}{Colors.ENDC}")
        else:
            print(f"\n{Colors.OKGREEN}[✓] لم يتم اكتشاف ثغرات واضحة{Colors.ENDC}")


# ═══════════════════════════════════════════════════════════════
# الدالة الرئيسية
# ═══════════════════════════════════════════════════════════════
def main():
    print(f"""
{Colors.OKCYAN}
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                             ║
║     ███████╗████████╗██╗  ██╗██╗ ██████╗ █████╗ ██╗                         ║
║     ██╔════╝╚══██╔══╝██║  ██║██║██╔════╝██╔══██╗██║                         ║
║     █████╗     ██║   ███████║██║██║     ███████║██║                         ║
║     ██╔══╝     ██║   ██╔══██║██║██║     ██╔══██║██║                         ║
║     ███████╗   ██║   ██║  ██║██║╚██████╗██║  ██║███████╗                    ║
║     ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝                    ║
║                                                                             ║
║           ADVANCED ETHICAL HACKING & PENETRATION TESTING TOOL               ║
║                    للاستخدام الأخلاقي والتعليمي فقط                          ║
╚═══════════════════════════════════════════════════════════════════════════════╝
{Colors.ENDC}
{Colors.FAIL}{Colors.BOLD}⚠️  تحذير هام / IMPORTANT WARNING ⚠️{Colors.ENDC}
{Colors.WARNING}هذه الأداة مخصصة للاستخدام الأخلاقي والتعليمي فقط!
لا تستخدمها على أي موقع إلا إذا كنت صاحبه أو لديك إذن كتابي صريح.
الاستخدام غير القانوني قد يعرضك للمساءلة القانونية!{Colors.ENDC}
""")

    # طلب إدخال الهدف
    target = input(f"{Colors.OKCYAN}[?] أدخل اسم النطاق (مثال: example.com): {Colors.ENDC}").strip()

    if not target:
        print(f"{Colors.FAIL}[-] خطأ: يجب إدخال اسم النطاق{Colors.ENDC}")
        return

    # إزالة البروتوكول إذا كان موجوداً
    target = target.replace("http://", "").replace("https://", "").split("/")[0]

    # تأكيد المستخدم
    confirm = input(f"\n{Colors.WARNING}هل لديك إذن لاختبار {target}? (yes/no): {Colors.ENDC}").strip().lower()
    if confirm not in ['yes', 'y']:
        print(f"{Colors.FAIL}[-] تم إلغاء العملية{Colors.ENDC}")
        return

    # إنشاء كائن الأداة
    tool = AdvancedEthicalHackingTool(target)
    tool.print_banner()

    # عرض القائمة
    while True:
        print(f"""
{Colors.OKCYAN}اختر نوع الفحص:{Colors.ENDC}
{Colors.OKGREEN}[1]{Colors.ENDC} فحص المنافذ (Port Scan)
{Colors.OKGREEN}[2]{Colors.ENDC} جمع معلومات DNS
{Colors.OKGREEN}[3]{Colors.ENDC} استكشاف النطاقات الفرعية
{Colors.OKGREEN}[4]{Colors.ENDC} معلومات السيرفر والتقنيات
{Colors.OKGREEN}[5]{Colors.ENDC} فحص SSL/TLS
{Colors.OKGREEN}[6]{Colors.ENDC} فحص الملفات الحساسة
{Colors.OKGREEN}[7]{Colors.ENDC} فحص robots.txt
{Colors.OKGREEN}[8]{Colors.ENDC} فحص رؤوس الأمان
{Colors.OKGREEN}[9]{Colors.ENDC} اختبار Clickjacking
{Colors.OKGREEN}[10]{Colors.ENDC} اختبار Open Redirect
{Colors.OKGREEN}[11]{Colors.ENDC} اختبار SQL Injection
{Colors.OKGREEN}[12]{Colors.ENDC} اختبار XSS
{Colors.OKGREEN}[13]{Colors.ENDC} فحص شامل (كل ما سبق)
{Colors.OKGREEN}[14]{Colors.ENDC} إنشاء تقرير JSON
{Colors.OKGREEN}[15]{Colors.ENDC} إنشاء تقرير HTML
{Colors.OKGREEN}[16]{Colors.ENDC} عرض التقرير التفصيلي
{Colors.OKGREEN}[0]{Colors.ENDC} خروج
        """)

        choice = input(f"{Colors.OKCYAN}[?] اختر خياراً (0-16): {Colors.ENDC}").strip()

        url = f"https://{target}"

        if choice == "1":
            print(f"\n{Colors.OKCYAN}[1] فحص المنافذ الشائعة فقط{Colors.ENDC}")
            print(f"{Colors.OKCYAN}[2] فحص نطاق مخصص{Colors.ENDC}")
            port_choice = input(f"{Colors.OKCYAN}[?] اختر: {Colors.ENDC}").strip()

            if port_choice == "1":
                tool.port_scan(common_only=True)
            else:
                start = input(f"{Colors.OKCYAN}[?] منفذ البداية (افتراضي 1): {Colors.ENDC}").strip()
                end = input(f"{Colors.OKCYAN}[?] منفذ النهاية (افتراضي 1000): {Colors.ENDC}").strip()
                start_port = int(start) if start.isdigit() else 1
                end_port = int(end) if end.isdigit() else 1000
                tool.port_scan(start_port, end_port)

        elif choice == "2":
            tool.get_dns_info()

        elif choice == "3":
            tool.enumerate_subdomains()

        elif choice == "4":
            tool.get_server_info(url)

        elif choice == "5":
            tool.check_ssl()

        elif choice == "6":
            tool.check_sensitive_files(url)

        elif choice == "7":
            tool.check_robots_txt(url)

        elif choice == "8":
            tool.check_security_headers(url)

        elif choice == "9":
            tool.test_clickjacking(url)

        elif choice == "10":
            tool.test_open_redirect(url)

        elif choice == "11":
            test_url = input(f"{Colors.OKCYAN}[?] أدخل الرابط الكامل للاختبار: {Colors.ENDC}").strip()
            if test_url:
                tool.test_sql_injection(test_url)
            else:
                tool.test_sql_injection(url)

        elif choice == "12":
            test_url = input(f"{Colors.OKCYAN}[?] أدخل الرابط الكامل للاختبار: {Colors.ENDC}").strip()
            if test_url:
                tool.test_xss(test_url)
            else:
                tool.test_xss(url)

        elif choice == "13":
            tool.full_scan(url)

        elif choice == "14":
            filename = input(f"{Colors.OKCYAN}[?] اسم ملف التقرير (اضغط Enter للاسم الافتراضي): {Colors.ENDC}").strip()
            if filename:
                tool.generate_report(filename)
            else:
                tool.generate_report()

        elif choice == "15":
            filename = input(f"{Colors.OKCYAN}[?] اسم ملف HTML (اضغط Enter للاسم الافتراضي): {Colors.ENDC}").strip()
            if filename:
                tool.generate_html_report(filename)
            else:
                tool.generate_html_report()

        elif choice == "16":
            tool.print_detailed_report()

        elif choice == "0":
            print(f"\n{Colors.OKGREEN}[✓] شكراً لاستخدام الأداة!{Colors.ENDC}")
            break

        else:
            print(f"{Colors.FAIL}[-] خيار غير صالح{Colors.ENDC}")

        input(f"\n{Colors.OKCYAN}اضغط Enter للمتابعة...{Colors.ENDC}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.WARNING}[!] تم إيقاف الأداة من قبل المستخدم{Colors.ENDC}")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Colors.FAIL}[-] خطأ: {e}{Colors.ENDC}")
        sys.exit(1)
