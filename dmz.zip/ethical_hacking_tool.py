#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    ETHICAL HACKING & PENETRATION TESTING TOOL                 ║
║                              للاستخدام الأخلاقي فقط                            ║
╚═══════════════════════════════════════════════════════════════════════════════╝

⚠️  WARNING / تحذير ⚠️
هذه الأداة مخصصة للاستخدام الأخلاقي والتعليمي فقط!
لا تستخدم هذه الأداة على أي موقع إلا إذا كنت:
1- صاحب الموقع، أو
2- لديك إذن كتابي صريح من صاحب الموقع

الاستخدام غير القانوني قد يعرضك للمساءلة القانونية!

المبرمج: أداة احترافية لاختبار الاختراق
"""

import socket
import requests
import ssl
import json
import time
import sys
import re
import threading
from urllib.parse import urljoin, urlparse, parse_qs
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import subprocess
import warnings
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

# الألوان للعرض
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

class EthicalHackingTool:
    def __init__(self, target):
        self.target = target
        self.results = {
            "target": target,
            "scan_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "open_ports": [],
            "services": {},
            "vulnerabilities": [],
            "server_info": {},
            "headers": {},
            "technologies": [],
            "dns_info": {},
            "ssl_info": {},
            "directories": [],
            "sql_injection_tests": [],
            "xss_tests": []
        }
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })

    def print_banner(self):
        banner = f"""
{Colors.OKCYAN}
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    🔒 ETHICAL HACKING & PENTEST TOOL 🔒                       ║
║                         للاستخدام الأخلاقي والتعليمي فقط                       ║
╚═══════════════════════════════════════════════════════════════════════════════╝
{Colors.ENDC}
{Colors.WARNING}⚠️  تحذير: استخدم هذه الأداة فقط على مواقع تملكها أو لديك إذن باختبارها ⚠️{Colors.ENDC}

{Colors.OKGREEN}[+] الهدف: {self.target}{Colors.ENDC}
{Colors.OKGREEN}[+] تاريخ الفحص: {self.results["scan_date"]}{Colors.ENDC}
"""
        print(banner)

    # ═══════════════════════════════════════════════════════════════
    # 1. فحص المنافذ (Port Scanning)
    # ═══════════════════════════════════════════════════════════════
    def scan_port(self, port):
        """فحص منفذ واحد"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((self.target, port))
            if result == 0:
                try:
                    service = socket.getservbyport(port)
                except:
                    service = "unknown"
                self.results["open_ports"].append({
                    "port": port,
                    "service": service,
                    "state": "open"
                })
                print(f"{Colors.OKGREEN}[+] المنفذ المفتوح: {port}/tcp - {service}{Colors.ENDC}")
            sock.close()
        except Exception as e:
            pass

    def port_scan(self, start_port=1, end_port=1000):
        """فحص المنافذ الشامل"""
        print(f"\n{Colors.HEADER}[*] بدء فحص المنافذ من {start_port} إلى {end_port}...{Colors.ENDC}\n")

        with ThreadPoolExecutor(max_workers=100) as executor:
            futures = [executor.submit(self.scan_port, port) for port in range(start_port, end_port + 1)]
            for future in as_completed(futures):
                pass

        print(f"\n{Colors.OKGREEN}[✓] تم اكتشاف {len(self.results['open_ports'])} منفذ مفتوح{Colors.ENDC}\n")

    # ═══════════════════════════════════════════════════════════════
    # 2. جمع المعلومات (Reconnaissance)
    # ═══════════════════════════════════════════════════════════════
    def get_dns_info(self):
        """جمع معلومات DNS"""
        print(f"{Colors.HEADER}[*] جمع معلومات DNS...{Colors.ENDC}")
        try:
            # IP Address
            ip = socket.gethostbyname(self.target)
            self.results["dns_info"]["ip"] = ip
            print(f"{Colors.OKGREEN}[+] عنوان IP: {ip}{Colors.ENDC}")

            # Reverse DNS
            try:
                reverse_dns = socket.gethostbyaddr(ip)
                self.results["dns_info"]["reverse_dns"] = reverse_dns[0]
                print(f"{Colors.OKGREEN}[+] Reverse DNS: {reverse_dns[0]}{Colors.ENDC}")
            except:
                pass

        except Exception as e:
            print(f"{Colors.FAIL}[-] خطأ في جمع معلومات DNS: {e}{Colors.ENDC}")

    def get_server_info(self, url):
        """جمع معلومات السيرفر"""
        print(f"\n{Colors.HEADER}[*] جمع معلومات السيرفر...{Colors.ENDC}")
        try:
            response = self.session.get(url, timeout=10, verify=False)
            headers = response.headers
            self.results["headers"] = dict(headers)

            # Server
            server = headers.get('Server', 'Unknown')
            self.results["server_info"]["server"] = server
            print(f"{Colors.OKGREEN}[+] نوع السيرفر: {server}{Colors.ENDC}")

            # Powered By
            powered_by = headers.get('X-Powered-By', 'Unknown')
            self.results["server_info"]["powered_by"] = powered_by
            if powered_by != 'Unknown':
                print(f"{Colors.OKGREEN}[+] تقنية السيرفر: {powered_by}{Colors.ENDC}")

            # Content-Type
            content_type = headers.get('Content-Type', 'Unknown')
            print(f"{Colors.OKGREEN}[+] نوع المحتوى: {content_type}{Colors.ENDC}")

            # Detect Technologies
            self.detect_technologies(headers, response.text)

        except Exception as e:
            print(f"{Colors.FAIL}[-] خطأ: {e}{Colors.ENDC}")

    def detect_technologies(self, headers, content):
        """الكشف عن التقنيات المستخدمة"""
        print(f"\n{Colors.HEADER}[*] الكشف عن التقنيات المستخدمة...{Colors.ENDC}")

        technologies = []

        # Check headers
        tech_signatures = {
            'WordPress': ['wp-content', 'wp-includes'],
            'Drupal': ['drupal', 'Drupal'],
            'Joomla': ['joomla', 'Joomla'],
            'React': ['react', 'reactjs'],
            'Angular': ['angular', 'ng-'],
            'Vue.js': ['vue', 'vue.js'],
            'jQuery': ['jquery'],
            'Bootstrap': ['bootstrap'],
            'PHP': ['PHP'],
            'ASP.NET': ['ASP.NET', 'X-AspNet-Version'],
            'Nginx': ['nginx'],
            'Apache': ['apache', 'Apache'],
            'IIS': ['IIS'],
            'CloudFlare': ['cloudflare'],
            'AWS': ['aws', 'amazonaws'],
        }

        for tech, signatures in tech_signatures.items():
            for signature in signatures:
                if signature in str(headers) or signature in content:
                    if tech not in technologies:
                        technologies.append(tech)
                        print(f"{Colors.OKGREEN}[+] تم اكتشاف: {tech}{Colors.ENDC}")
                        break

        self.results["technologies"] = technologies

    # ═══════════════════════════════════════════════════════════════
    # 3. فحص SSL/TLS
    # ═══════════════════════════════════════════════════════════════
    def check_ssl(self):
        """فحص شهادة SSL"""
        print(f"\n{Colors.HEADER}[*] فحص SSL/TLS...{Colors.ENDC}")
        try:
            context = ssl.create_default_context()
            with socket.create_connection((self.target, 443), timeout=5) as sock:
                with context.wrap_socket(sock, server_hostname=self.target) as ssock:
                    cert = ssock.getpeercert()
                    cipher = ssock.cipher()
                    version = ssock.version()

                    self.results["ssl_info"] = {
                        "version": version,
                        "cipher": cipher[0],
                        "issuer": cert.get('issuer'),
                        "subject": cert.get('subject'),
                        "not_after": cert.get('notAfter'),
                        "not_before": cert.get('notBefore')
                    }

                    print(f"{Colors.OKGREEN}[+] إصدار SSL/TLS: {version}{Colors.ENDC}")
                    print(f"{Colors.OKGREEN}[+] التشفير المستخدم: {cipher[0]}{Colors.ENDC}")
                    print(f"{Colors.OKGREEN}[+] الجهة المصدرة: {cert.get('issuer')}{Colors.ENDC}")
                    print(f"{Colors.OKGREEN}[+] صالح حتى: {cert.get('notAfter')}{Colors.ENDC}")

        except Exception as e:
            print(f"{Colors.FAIL}[-] خطأ في فحص SSL: {e}{Colors.ENDC}")

    # ═══════════════════════════════════════════════════════════════
    # 4. فحص الثغرات (Vulnerability Scanning)
    # ═══════════════════════════════════════════════════════════════
    def check_security_headers(self, url):
        """فحص رؤوس الأمان"""
        print(f"\n{Colors.HEADER}[*] فحص رؤوس الأمان...{Colors.ENDC}")

        try:
            response = self.session.get(url, timeout=10, verify=False)
            headers = response.headers

            security_headers = {
                'Strict-Transport-Security': 'HSTS - يفرض استخدام HTTPS',
                'Content-Security-Policy': 'CSP - يمنع هجمات XSS',
                'X-Frame-Options': 'يمنع هجمات Clickjacking',
                'X-Content-Type-Options': 'يمنع MIME-sniffing',
                'X-XSS-Protection': 'حماية XSS إضافية',
                'Referrer-Policy': 'يتحكم في معلومات المرجع',
                'Permissions-Policy': 'يتحكم في ميزات المتصفح'
            }

            missing_headers = []

            for header, description in security_headers.items():
                if header in headers:
                    print(f"{Colors.OKGREEN}[✓] {header}: موجود - {description}{Colors.ENDC}")
                else:
                    missing_headers.append(header)
                    print(f"{Colors.FAIL}[✗] {header}: مفقود - {description}{Colors.ENDC}")
                    self.results["vulnerabilities"].append({
                        "type": "Missing Security Header",
                        "header": header,
                        "description": description,
                        "severity": "Medium"
                    })

            return missing_headers

        except Exception as e:
            print(f"{Colors.FAIL}[-] خطأ: {e}{Colors.ENDC}")
            return []

    def check_common_vulnerabilities(self, url):
        """فحص الثغرات الشائعة"""
        print(f"\n{Colors.HEADER}[*] فحص الثغرات الشائعة...{Colors.ENDC}")

        vulnerabilities = []

        # Check for directory listing
        common_dirs = ['/admin/', '/backup/', '/config/', '/test/', '/api/', '/.env', '/phpinfo.php']

        print(f"{Colors.OKCYAN}[*] فحص المجلدات الشائعة...{Colors.ENDC}")
        for directory in common_dirs:
            try:
                test_url = urljoin(url, directory)
                response = self.session.get(test_url, timeout=5, verify=False, allow_redirects=False)
                if response.status_code == 200:
                    print(f"{Colors.WARNING}[!] المجلد/الملف موجود: {directory}{Colors.ENDC}")
                    self.results["directories"].append({
                        "path": directory,
                        "status": response.status_code,
                        "url": test_url
                    })
                    vulnerabilities.append({
                        "type": "Exposed Directory/File",
                        "path": directory,
                        "severity": "High"
                    })
            except:
                pass

        return vulnerabilities

    # ═══════════════════════════════════════════════════════════════
    # 5. فحص SQL Injection
    # ═══════════════════════════════════════════════════════════════
    def test_sql_injection(self, url):
        """اختبار SQL Injection"""
        print(f"\n{Colors.HEADER}[*] اختبار SQL Injection...{Colors.ENDC}")

        sql_payloads = [
            "'",
            "''",
            "' OR '1'='1",
            "' OR '1'='1' --",
            "' OR '1'='1' /*",
            "' OR 1=1",
            "' OR 1=1 --",
            "' OR 1=1 /*",
            "1' ORDER BY 1--+",
            "1' ORDER BY 2--+",
            "1' ORDER BY 3--+",
        ]

        error_signatures = [
            "sql syntax",
            "mysql_fetch",
            "pg_query",
            "sqlite_query",
            "ORA-",
            "SQL Server",
            "ODBC",
            "mysqli"
        ]

        parsed = urlparse(url)
        if parsed.query:
            params = parse_qs(parsed.query)

            for param in params:
                for payload in sql_payloads:
                    try:
                        test_params = params.copy()
                        test_params[param] = payload
                        test_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}?"
                        test_url += "&".join([f"{k}={v[0]}" for k, v in test_params.items()])

                        response = self.session.get(test_url, timeout=10, verify=False)

                        for error in error_signatures:
                            if error.lower() in response.text.lower():
                                vuln = {
                                    "type": "SQL Injection",
                                    "parameter": param,
                                    "payload": payload,
                                    "url": test_url,
                                    "evidence": error,
                                    "severity": "Critical"
                                }
                                self.results["sql_injection_tests"].append(vuln)
                                self.results["vulnerabilities"].append(vuln)
                                print(f"{Colors.FAIL}[!!!] تم اكتشاف SQL Injection في المعامل: {param}{Colors.ENDC}")
                                print(f"{Colors.FAIL}    الحمولة: {payload}{Colors.ENDC}")
                                print(f"{Colors.FAIL}    الدليل: {error}{Colors.ENDC}")
                                return

                    except Exception as e:
                        pass

        print(f"{Colors.OKGREEN}[✓] لم يتم اكتشاف SQL Injection واضح{Colors.ENDC}")

    # ═══════════════════════════════════════════════════════════════
    # 6. فحص XSS
    # ═══════════════════════════════════════════════════════════════
    def test_xss(self, url):
        """اختبار XSS"""
        print(f"\n{Colors.HEADER}[*] اختبار Cross-Site Scripting (XSS)...{Colors.ENDC}")

        xss_payloads = [
            "<script>alert('XSS')</script>",
            "<img src=x onerror=alert('XSS')>",
            "<svg onload=alert('XSS')>",
            "javascript:alert('XSS')",
            "<body onload=alert('XSS')>",
            "<iframe src=javascript:alert('XSS')>",
        ]

        parsed = urlparse(url)
        if parsed.query:
            params = parse_qs(parsed.query)

            for param in params:
                for payload in xss_payloads:
                    try:
                        test_params = params.copy()
                        test_params[param] = payload
                        test_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}?"
                        test_url += "&".join([f"{k}={v[0]}" for k, v in test_params.items()])

                        response = self.session.get(test_url, timeout=10, verify=False)

                        if payload in response.text:
                            vuln = {
                                "type": "Cross-Site Scripting (XSS)",
                                "parameter": param,
                                "payload": payload,
                                "url": test_url,
                                "severity": "High"
                            }
                            self.results["xss_tests"].append(vuln)
                            self.results["vulnerabilities"].append(vuln)
                            print(f"{Colors.FAIL}[!!!] تم اكتشاف XSS في المعامل: {param}{Colors.ENDC}")
                            print(f"{Colors.FAIL}    الحمولة: {payload}{Colors.ENDC}")
                            return

                    except Exception as e:
                        pass

        print(f"{Colors.OKGREEN}[✓] لم يتم اكتشاف XSS واضح{Colors.ENDC}")

    # ═══════════════════════════════════════════════════════════════
    # 7. فحص شامل للموقع
    # ═══════════════════════════════════════════════════════════════
    def full_scan(self, url):
        """فحص شامل للموقع"""
        print(f"\n{Colors.BOLD}{Colors.OKCYAN}╔═══════════════════════════════════════════════════════════════╗{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}║                    بدء الفحص الشامل                          ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}╚═══════════════════════════════════════════════════════════════╝{Colors.ENDC}\n")

        # 1. DNS Info
        self.get_dns_info()

        # 2. Server Info
        self.get_server_info(url)

        # 3. SSL Check
        self.check_ssl()

        # 4. Security Headers
        self.check_security_headers(url)

        # 5. Common Vulnerabilities
        self.check_common_vulnerabilities(url)

        # 6. SQL Injection Test
        self.test_sql_injection(url)

        # 7. XSS Test
        self.test_xss(url)

        print(f"\n{Colors.BOLD}{Colors.OKGREEN}╔═══════════════════════════════════════════════════════════════╗{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKGREEN}║                    تم الانتهاء من الفحص الشامل               ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKGREEN}╚═══════════════════════════════════════════════════════════════╝{Colors.ENDC}\n")

    # ═══════════════════════════════════════════════════════════════
    # 8. إنشاء التقرير
    # ═══════════════════════════════════════════════════════════════
    def generate_report(self, filename=None):
        """إنشاء تقرير شامل"""
        if filename is None:
            filename = f"pentest_report_{self.target.replace('.', '_')}_{int(time.time())}.json"

        # حساب إحصائيات
        critical = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "Critical"])
        high = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "High"])
        medium = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "Medium"])
        low = len([v for v in self.results["vulnerabilities"] if v.get("severity") == "Low"])

        self.results["summary"] = {
            "total_vulnerabilities": len(self.results["vulnerabilities"]),
            "critical": critical,
            "high": high,
            "medium": medium,
            "low": low,
            "open_ports": len(self.results["open_ports"]),
            "technologies_found": len(self.results["technologies"])
        }

        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=4, ensure_ascii=False)

        print(f"{Colors.OKGREEN}[✓] تم حفظ التقرير في: {filename}{Colors.ENDC}")

        # طباعة ملخص
        print(f"\n{Colors.BOLD}{Colors.HEADER}╔═══════════════════════════════════════════════════════════════╗{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}║                      ملخص النتائج                            ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}╠═══════════════════════════════════════════════════════════════╣{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}║  إجمالي الثغرات: {len(self.results['vulnerabilities'])}                                          ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.FAIL}║  خطيرة (Critical): {critical}                                        ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.WARNING}║  عالية (High): {high}                                              ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}║  متوسطة (Medium): {medium}                                         ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKGREEN}║  منخفضة (Low): {low}                                               ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}║  المنافذ المفتوحة: {len(self.results['open_ports'])}                                         ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}║  التقنيات المكتشفة: {len(self.results['technologies'])}                                        ║{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.HEADER}╚═══════════════════════════════════════════════════════════════╝{Colors.ENDC}\n")

        return filename

    def print_detailed_report(self):
        """طباعة تقرير مفصل"""
        print(f"\n{Colors.BOLD}{Colors.OKCYAN}═══════════════════════════════════════════════════════════════{Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}                    التقرير التفصيلي                          {Colors.ENDC}")
        print(f"{Colors.BOLD}{Colors.OKCYAN}═══════════════════════════════════════════════════════════════{Colors.ENDC}\n")

        # المنافذ المفتوحة
        if self.results["open_ports"]:
            print(f"{Colors.HEADER}[+] المنافذ المفتوحة:{Colors.ENDC}")
            for port in self.results["open_ports"]:
                print(f"    {Colors.OKGREEN}- المنفذ {port['port']}/tcp: {port['service']}{Colors.ENDC}")

        # معلومات السيرفر
        if self.results["server_info"]:
            print(f"\n{Colors.HEADER}[+] معلومات السيرفر:{Colors.ENDC}")
            for key, value in self.results["server_info"].items():
                print(f"    {Colors.OKGREEN}- {key}: {value}{Colors.ENDC}")

        # التقنيات
        if self.results["technologies"]:
            print(f"\n{Colors.HEADER}[+] التقنيات المكتشفة:{Colors.ENDC}")
            for tech in self.results["technologies"]:
                print(f"    {Colors.OKGREEN}- {tech}{Colors.ENDC}")

        # الثغرات
        if self.results["vulnerabilities"]:
            print(f"\n{Colors.HEADER}[+] الثغرات المكتشفة:{Colors.ENDC}")
            for i, vuln in enumerate(self.results["vulnerabilities"], 1):
                severity_color = Colors.OKGREEN
                if vuln.get("severity") == "Critical":
                    severity_color = Colors.FAIL
                elif vuln.get("severity") == "High":
                    severity_color = Colors.WARNING
                elif vuln.get("severity") == "Medium":
                    severity_color = Colors.OKCYAN

                print(f"\n    {Colors.BOLD}{severity_color}[{i}] {vuln['type']}{Colors.ENDC}")
                print(f"    {Colors.OKCYAN}الخطورة: {vuln.get('severity', 'Unknown')}{Colors.ENDC}")
                if 'parameter' in vuln:
                    print(f"    {Colors.OKCYAN}المعامل: {vuln['parameter']}{Colors.ENDC}")
                if 'description' in vuln:
                    print(f"    {Colors.OKCYAN}الوصف: {vuln['description']}{Colors.ENDC}")
                if 'payload' in vuln:
                    print(f"    {Colors.OKCYAN}الحمولة: {vuln['payload']}{Colors.ENDC}")
        else:
            print(f"\n{Colors.OKGREEN}[✓] لم يتم اكتشاف ثغرات واضحة{Colors.ENDC}")


# ═══════════════════════════════════════════════════════════════
# الدالة الرئيسية
# ═══════════════════════════════════════════════════════════════
def main():
    print(f"""
{Colors.OKCYAN}
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                             ║
║     ███████╗████████╗██╗  ██╗██╗ ██████╗ █████╗ ██╗                         ║
║     ██╔════╝╚══██╔══╝██║  ██║██║██╔════╝██╔══██╗██║                         ║
║     █████╗     ██║   ███████║██║██║     ███████║██║                         ║
║     ██╔══╝     ██║   ██╔══██║██║██║     ██╔══██║██║                         ║
║     ███████╗   ██║   ██║  ██║██║╚██████╗██║  ██║███████╗                    ║
║     ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝                    ║
║                                                                             ║
║           ETHICAL HACKING & PENETRATION TESTING TOOL                        ║
║                    للاستخدام الأخلاقي والتعليمي فقط                          ║
╚═══════════════════════════════════════════════════════════════════════════════╝
{Colors.ENDC}
{Colors.FAIL}{Colors.BOLD}⚠️  تحذير هام / IMPORTANT WARNING ⚠️{Colors.ENDC}
{Colors.WARNING}هذه الأداة مخصصة للاستخدام الأخلاقي والتعليمي فقط!
لا تستخدمها على أي موقع إلا إذا كنت صاحبه أو لديك إذن كتابي صريح.
الاستخدام غير القانوني قد يعرضك للمساءلة القانونية!{Colors.ENDC}
""")

    # طلب إدخال الهدف
    target = input(f"{Colors.OKCYAN}[?] أدخل اسم النطاق (مثال: example.com): {Colors.ENDC}").strip()

    if not target:
        print(f"{Colors.FAIL}[-] خطأ: يجب إدخال اسم النطاق{Colors.ENDC}")
        return

    # إزالة البروتوكول إذا كان موجوداً
    target = target.replace("http://", "").replace("https://", "").split("/")[0]

    # تأكيد المستخدم
    confirm = input(f"\n{Colors.WARNING}هل لديك إذن لاختبار {target}? (yes/no): {Colors.ENDC}").strip().lower()
    if confirm not in ['yes', 'y']:
        print(f"{Colors.FAIL}[-] تم إلغاء العملية{Colors.ENDC}")
        return

    # إنشاء كائن الأداة
    tool = EthicalHackingTool(target)
    tool.print_banner()

    # عرض القائمة
    while True:
        print(f"""
{Colors.OKCYAN}اختر نوع الفحص:{Colors.ENDC}
{Colors.OKGREEN}[1]{Colors.ENDC} فحص المنافذ (Port Scan)
{Colors.OKGREEN}[2]{Colors.ENDC} جمع معلومات DNS
{Colors.OKGREEN}[3]{Colors.ENDC} معلومات السيرفر والتقنيات
{Colors.OKGREEN}[4]{Colors.ENDC} فحص SSL/TLS
{Colors.OKGREEN}[5]{Colors.ENDC} فحص رؤوس الأمان
{Colors.OKGREEN}[6]{Colors.ENDC} فحص الثغرات الشائعة
{Colors.OKGREEN}[7]{Colors.ENDC} اختبار SQL Injection
{Colors.OKGREEN}[8]{Colors.ENDC} اختبار XSS
{Colors.OKGREEN}[9]{Colors.ENDC} فحص شامل (كل ما سبق)
{Colors.OKGREEN}[10]{Colors.ENDC} إنشاء تقرير JSON
{Colors.OKGREEN}[11]{Colors.ENDC} عرض التقرير التفصيلي
{Colors.OKGREEN}[0]{Colors.ENDC} خروج
        """)

        choice = input(f"{Colors.OKCYAN}[?] اختر خياراً (0-11): {Colors.ENDC}").strip()

        url = f"https://{target}"

        if choice == "1":
            start = input(f"{Colors.OKCYAN}[?] منفذ البداية (افتراضي 1): {Colors.ENDC}").strip()
            end = input(f"{Colors.OKCYAN}[?] منفذ النهاية (افتراضي 1000): {Colors.ENDC}").strip()
            start_port = int(start) if start.isdigit() else 1
            end_port = int(end) if end.isdigit() else 1000
            tool.port_scan(start_port, end_port)

        elif choice == "2":
            tool.get_dns_info()

        elif choice == "3":
            tool.get_server_info(url)

        elif choice == "4":
            tool.check_ssl()

        elif choice == "5":
            tool.check_security_headers(url)

        elif choice == "6":
            tool.check_common_vulnerabilities(url)

        elif choice == "7":
            test_url = input(f"{Colors.OKCYAN}[?] أدخل الرابط الكامل للاختبار: {Colors.ENDC}").strip()
            if test_url:
                tool.test_sql_injection(test_url)
            else:
                tool.test_sql_injection(url)

        elif choice == "8":
            test_url = input(f"{Colors.OKCYAN}[?] أدخل الرابط الكامل للاختبار: {Colors.ENDC}").strip()
            if test_url:
                tool.test_xss(test_url)
            else:
                tool.test_xss(url)

        elif choice == "9":
            tool.full_scan(url)

        elif choice == "10":
            filename = input(f"{Colors.OKCYAN}[?] اسم ملف التقرير (اضغط Enter للاسم الافتراضي): {Colors.ENDC}").strip()
            if filename:
                tool.generate_report(filename)
            else:
                tool.generate_report()

        elif choice == "11":
            tool.print_detailed_report()

        elif choice == "0":
            print(f"\n{Colors.OKGREEN}[✓] شكراً لاستخدام الأداة!{Colors.ENDC}")
            break

        else:
            print(f"{Colors.FAIL}[-] خيار غير صالح{Colors.ENDC}")

        input(f"\n{Colors.OKCYAN}اضغط Enter للمتابعة...{Colors.ENDC}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.WARNING}[!] تم إيقاف الأداة من قبل المستخدم{Colors.ENDC}")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Colors.FAIL}[-] خطأ: {e}{Colors.ENDC}")
        sys.exit(1)
